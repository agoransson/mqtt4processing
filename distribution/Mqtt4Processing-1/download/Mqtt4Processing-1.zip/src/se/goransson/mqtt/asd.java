package se.goransson.mqtt;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class asd {

	private ConnectedThread mConnectedThread;

	public asd(String host, int port) throws IOException {
		InetAddress address = InetAddress.getByName(host);
		
		Socket mSocket = new Socket(address, port);
		
		mConnectedThread = new ConnectedThread(mSocket);
		
		mConnectedThread.start();
	}

	/**
	 * Write to the ConnectedThread in an unsynchronized manner
	 * 
	 * @param out
	 *            The bytes to write
	 * @see ConnectedThread#write(byte[])
	 */
	public void write(byte[] out) {
		// Create temporary object
		ConnectedThread r;
		// Synchronize a copy of the ConnectedThread
		synchronized (this) {
//			if (mState != STATE_CONNECTED)
//				return;
			r = mConnectedThread;
		}
		// Perform the write unsynchronized
		r.write(out);
	}
	
	private class ConnectedThread extends Thread {
		private InputStream mInputStream;
		private OutputStream mOutputStream;
		private Socket mSocket;

		public ConnectedThread(Socket socket) {
			InputStream tmpIn = null;
			OutputStream tmpOut = null;

			// Get the BluetoothSocket input and output streams
			try {
				tmpIn = socket.getInputStream();
				tmpOut = socket.getOutputStream();
			} catch (IOException e) {
				System.out.println( "--- Error in ConnectedThread constructor");
				e.printStackTrace();
			}

			mInputStream = tmpIn;
			mOutputStream = tmpOut;
		}

		public void run() {
			byte[] buffer = new byte[1024];
			int bytes;

			// Keep listening to the InputStream while connected
			while (true) {
				try {
					// Read from the InputStream
					bytes = mInputStream.read(buffer);
//					System.out.println("bytes: " + bytes);
//					if( bytes > 0 ){
//						byte type = (byte) ((buffer[0] >> 4) & 0x0f);
//						System.out.println( "type: " + type);
//					}
					// Send the obtained bytes to the UI Activity
//					mHandler.obtainMessage(BluetoothChat.MESSAGE_READ, bytes,
//							-1, buffer).sendToTarget();
				} catch (IOException e) {
					System.out.println( "--- Error in thread");
					e.printStackTrace();
//					connectionLost();
					// Start the service over to restart listening mode
//					BluetoothChatService.this.start();
					break;
				}
			}
		}
		
		/**
		 * Write to the connected OutStream.
		 * 
		 * @param buffer
		 *            The bytes to write
		 */
		public void write(byte[] buffer) {
			try {
				mOutputStream.write(buffer);

				// Share the sent message back to the UI Activity
//				mHandler.obtainMessage(BluetoothChat.MESSAGE_WRITE, -1, -1,
//						buffer).sendToTarget();
			} catch (IOException e) {
				System.out.println( "--- Error in write");
				e.printStackTrace();
			}
		}

		public void cancel() {
			try {
				mSocket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
